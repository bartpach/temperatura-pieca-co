/* vim: set sw=8 ts=8 si et: */

#ifndef ALIBC_OLD
#include <util/delay.h>
#else
#include <avr/delay.h>
#endif

